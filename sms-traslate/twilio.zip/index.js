const twilio = require('twilio')

function main(p) {
  if (p.ssid === undefined ||
      p.token === undefined ||
      p.from === undefined) {
    return { error: 'credentials missing' }
  }

  if (p.Body === undefined ||
      p.number === undefined) {
    return { error: 'a number and body are required' }
  }

  let client = new twilio(p.ssid, p.token)

  return client.messages.create({
	body: p.Body,
	to: p.number, // Text this number
	from: p.from  // From a valid Twilio number
  })
  .then(message => {
    console.log(message)
    return { html: "<Response><Message>OK</Message></Response>" }
  })
  .catch(err => {
    console.log(err)
    return { error: err }
  })
}

exports.main = main